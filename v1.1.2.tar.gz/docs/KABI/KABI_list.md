# KABI Compatibility List For Arm64

For details,see [https://gitee.com/openeuler/kernel/tree/kernel-4.19/kabi/2019-V1](https://gitee.com/openeuler/kernel/tree/kernel-4.19/kabi/2019-V1).